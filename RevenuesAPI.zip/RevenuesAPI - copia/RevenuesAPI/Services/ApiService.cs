﻿using System.Net.Http.Headers;
using Refit;
using RevenuesAPI.Clients;
using RevenuesAPI.Clients.Responses;

namespace RevenuesAPI.Services
{
    public class ApiService
    {

        private readonly IApiClient _apiService;

        public ApiService(string apiUrl, string accessToken)
        {
            var httpClient = new HttpClient
            {
                BaseAddress = new Uri(apiUrl)
            };

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            _apiService = RestService.For<IApiClient>(httpClient);
        }


        public async Task<List<QuantityVehicleRes>> GetQuantityVehicles(string formattedDate)
        {
            try
            {
                var response = await _apiService.GetQuantityVehicles(formattedDate);
                Console.WriteLine(" Items found for quantity: " + response.Count);
                return response;
            }
            catch (ApiException ex)
            {
                Console.WriteLine(" Error consuming service revenues: " + ex.StatusCode);
                return new List<QuantityVehicleRes>();
            }
        }

        public async Task<List<RevenueVehicleRes>> GetRevenueVehicles(string formattedDate)
        {
            try
            {
                var response = await _apiService.GetRevenueVehicles(formattedDate);
                Console.WriteLine(" Items found for revenues: " + response.Count);
                return response;
            }
            catch (ApiException ex)
            {
                Console.WriteLine(" Error consuming service revenues: " + ex.StatusCode);
                return new List<RevenueVehicleRes>();
            }
        }
    }
}
