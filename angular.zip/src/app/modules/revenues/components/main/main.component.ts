import {Component} from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent {
  private selectedComponent = "";

  closeComponent() {
    this.selectedComponent = "";
  }

  selectComponent(name: string) {
    this.selectedComponent = name;
  }

  isSelectComponent(name: string) {
    return this.selectedComponent == name;
  }

  isSelectAnyComponent() {
    return this.selectedComponent != '';
  }

}
