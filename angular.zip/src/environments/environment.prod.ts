export const environment = {
  production: true,
  envName: 'pdn',
  keyCloakHostUrl: 'http://34.125.152.223/',
  apiUrl: 'http://34.125.152.223/api/v1/revenues',
  realm: 'revenues',
  clientId: 'revenues-app',
};
